import "./chess.css";
//import  {Chessboard}  from "react-chessboard";
import React, { useState, useEffect, useRef } from "react";
import Tooltip from "@mui/material/Tooltip";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import KeyboardDoubleArrowLeftOutlinedIcon from "@mui/icons-material/KeyboardDoubleArrowLeftOutlined";
import KeyboardDoubleArrowRightOutlinedIcon from "@mui/icons-material/KeyboardDoubleArrowRightOutlined";
import IconButtonWithTooltip from "./upravljanjePozicijama";
import VremeIgraca from "./vremeIgraca";
import { Button } from "@mui/material";
import Chessboard from "chessboardjsx";
import Popup from "./popup";
import UnstyledSelectObjectValuesForm from "./colorPicker";
import UnstyledInputIntroduction from "./colorPicker";
import BasicSelect from "./colorPicker";

function Chess() {
  const [fenPositions, setFenPositions] = useState([]); // FEN pozicije iz fajla
  const [currentPosition, setCurrentPosition] = useState(""); // Trenutna FEN pozicija
  const [currentIndex, setCurrentIndex] = useState(0); // Indeks trenutne FEN pozicije
  const [showPopup, setShowPopup] = useState(false);
  const [reason, setReason] = useState("");
  const[colorBlack,setColorBlack]=useState("#8B4513");
  const[colorWhite,setColorWhite]=useState("#F5DEB3");

  const [fen, setFen] = useState("start"); // Početna FEN pozicija

  const rowNumbers = [8, 7, 6, 5, 4, 3, 2, 1];
  const columnLetters = ["A", "B", "C", "D", "E", "F", "G", "H"];

  const pickedColorForWhite = (color) => {
    console.log("Picked color stampam iz chessa", color);
    setColorWhite(color);

  };
  const pickedColorForBlack = (colorBlack,colorWhite) => {
    console.log("Picked color stampam iz chessa", colorBlack,colorWhite);
    setColorBlack(colorBlack);
    setColorWhite(colorWhite);

  };

  const socketRef = useRef(null);

  useEffect(() => {
    const address = "ws://192.168.1.29:8080"; // Adresa vašeg WebSocket servera
    if (!socketRef.current) {
      socketRef.current = new WebSocket(address);
    }
    const socket = socketRef.current;

    let i = 0;
    socket.onmessage = (event) => {
      const message = event.data;

      try {
        // Pokušaj parsiranja kao JSON
        const data = JSON.parse(message);

        if (data.end === "kraj") {
          setShowPopup(true);
          setReason(data.reason);
          return;
        }
      } catch (error) {
        // Ako nije JSON, koristi kao FEN
        console.log(`primio sam ${i}. fen`, message);
        i++;
        setFen(message); // update table
      }
    };

    socket.onclose = () => {
      console.log("WebSocket zatvoren");
    };

    socket.onerror = (error) => {
      console.error("WebSocket greška:", error);
    };

    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        // Proverava da li je socket otvoren
        socket.close();
      }
    };
  }, []); // Ovu komponentu pokrećete samo jednom kada se komponenta učita

  const petarHandler = () => {
    //alert("Ovo je obaveštenje!");
    setShowPopup(true);
  };

  const indexHandler = (param) => {
    console.log(
      "ulazim u index henlder, param je ",
      param,
      "current index je",
      currentIndex
    );
    console.log(fenPositions.length);

    if (currentIndex + param < fenPositions.length && currentIndex > 0) {
      // Ensure we're not going out of bounds
      const nextIndex = currentIndex + param; // Increment index
      setCurrentPosition(fenPositions[nextIndex]); // Set the next position
      setCurrentIndex(nextIndex); // Update the current index
      console.log("Povecao sam trenutni indeks za 1: ", nextIndex);
    }
  };

  const EndOrFinishHandler = (param) => {
    if (param === "pocetak") {
      console.log("pocetak");
      setCurrentPosition(fenPositions[0]);
      setCurrentIndex(0);
    } else {
      console.log("kraj");
      setCurrentPosition(fenPositions[fenPositions.length - 1]);
      setCurrentIndex(fenPositions.length);
    }
  };

  useEffect(() => {
    const loadFile = async () => {
      const response = await fetch("/FenExamples.txt");
      const text = await response.text();
      const lines = text
        .split("\n")
        .map((line) => line.trim()) // Trim svake linije da bi se uklonio \r
        .filter((line) => line !== ""); // Filtriraj prazne linije

      setFenPositions(lines);
      if (lines.length > 0) {
        setCurrentPosition(lines[0]); // Postavi prvu FEN poziciju
      }
    };

    loadFile();
  }, []);

  return (
    <div
      className="chess-board"
      style={{ display: "flex", flexDirection: "column" }}
    >
      <div style={{ display: "flex", flexDirection: "row" }}>
        <BasicSelect boja={"crnih"}  onSelectChange={pickedColorForBlack}>  </BasicSelect>

        <VremeIgraca
          time={"2:15"}
          style={{
            display: "inline-block", // Element će zauzeti samo onoliko prostora koliko je potrebno za sadržaj
            marginLeft: "auto", // Guraj ovaj div ka desno
            backgroundColor: "green",
            padding: "10px",
            marginTop: "10px",
            border: "2px solid black", // Okvir
            borderRadius: "5px", // Zaokruženi uglovi
          }}
        >
          {" "}
        </VremeIgraca>
      </div>
      {/* <Chessboard position={fen} /> */}

      <div
        style={{
          padding: "30px",
          display: "inline-block",
          position: "relative",
        }}
      >
        <Chessboard
          darkSquareStyle={{ backgroundColor: colorBlack }}
          lightSquareStyle={{ backgroundColor: colorWhite }}
          position={fen}
        />
        <div className="brojevi"
          style={{
            position: "absolute",
            top: "30px",
            right: "-7%",
            height: "560px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            border: "2px solid black",
          }}
        >
          {rowNumbers.map((number, index) => (
           <span
           style={{
             display: "flex",              // Postavljamo display na flex
             justifyContent: "center",     // Horizontalno centriramo
             alignItems: "center",         // Vertikalno centriramo
             textAlign: "center",          // Centriranje teksta (opciono)
             fontSize: "25px",
             color: "black",
             fontWeight: "bold",
             width: "70px",
             height: "70px",
             

           }}
           key={index}
         >
           {number}
         </span>
         
          ))}
        </div>
        <div  className="slova"
          style={{
            display: "flex",
            justifyContent: "center",
            
            width: "560px",
            border:"2px solid black",
            
            
          }}
        >
          {columnLetters.map((letter, index) => (
            <span
            style={{
              display: "inline-block", // Ili "block"
              flex: "1",
              textAlign: "center",
              fontSize: "25px",
              color: "black",
              fontWeight: "bold",
             
            }}
            key={index}
          >
            {letter}
          </span>
          
          ))}
        </div>
      </div>

      <div
        className="ispodTable"
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center", // Horizontalno centriranje strelica
          alignItems: "center", // Vertikalno centriranje strelica
          position: "relative", // Omogućava desni div da se pozicionira desno
        }}
      >
        <div className="strelice" style={{ display: "flex", gap: "10px" }}>
         

          <IconButtonWithTooltip
            title="pocetak"
            IconComponent={KeyboardDoubleArrowLeftOutlinedIcon}
            onClick={() => EndOrFinishHandler("pocetak")}
          />

          <IconButtonWithTooltip
            title="nazad"
            IconComponent={ArrowBackIcon}
            onClick={() => indexHandler(-1)}
          />

          <IconButtonWithTooltip
            title="napred"
            IconComponent={ArrowForwardIcon}
            onClick={() => indexHandler(1)}
          />

          <IconButtonWithTooltip
            title="kraj"
            IconComponent={KeyboardDoubleArrowRightOutlinedIcon}
            onClick={() => EndOrFinishHandler("kraj")}
          />
        </div>

        <VremeIgraca
          time={"2:15"}
          style={{
            display: "inline-block", // Element će zauzeti samo onoliko prostora koliko je potrebno za sadržaj
            marginLeft: "auto", // Guraj ovaj div ka desno
            backgroundColor: "green",
            padding: "10px",
            marginTop: "10px",
            border: "2px solid black", // Okvir
            borderRadius: "5px", // Zaokruženi uglovi
          }}
        >
          {" "}
        </VremeIgraca>

        <Button onClick={petarHandler}> Petar </Button>
        {showPopup && (
          <Popup reason={reason} onClose={() => setShowPopup(false)}>
            {" "}
          </Popup>
        )}
      </div>
    </div>
  );
}

export default Chess;
